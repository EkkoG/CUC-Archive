//
//  SYCommonUtils.h
//  CleanUp
//
//  Created by pzy on 2022/9/5.
//

#import <Foundation/Foundation.h>

@interface NSString (HttpSignature)

+(NSString *)dcHmacSHA256ThenBase64:(NSString *)key value:(NSString *)value;

+(NSString *)dcBase64UrlSafe:(NSString *)content;

- (NSString *)reverseSafeUrlString;

@end

@interface SYCommonUtils : NSObject

+ (NSData *)uncompressZippedData:(NSData *)compressedData;
+ (NSString *)decryptUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64 dataNeedBase64:(BOOL)dataNeedBase64;
+ (NSString *)decryptUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64;
+ (NSString *)requestSignatureWithAccessKey:(NSString *)accesskey URL:(NSString *)urlStr Method:(NSString *)method Parameters:(NSDictionary *)paramaters;
+ (NSString *)decryptStringDataUseDES:(NSData *)cipherData key:(NSString *)key keyNeedBase64:(BOOL)keyNeedBase64;

@end
