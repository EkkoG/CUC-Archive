//
//  AhhhBuyChannelIPCheckSessionManager.h
//  AhhhCSBuyChannelSDK
//
//  Created by Zy on 2021/6/23.
//

#import <AFNetworking/AFHTTPSessionManager.h>
#import "AhhhCSBuyChannel.h"

NS_ASSUME_NONNULL_BEGIN

@interface AhhhBuyChannelIPCheckSessionManager : AFHTTPSessionManager

@property (nonatomic, copy, readonly) NSString *desKey;

+(AhhhBuyChannelIPCheckSessionManager*)ahhhsharedBuyChannelIPCheckSessionManagerDomainName:(NSString *)domainName appleAppID:(NSString *)appleAppID signatureKey:(NSString *)signatureKey prodKey:(NSString *)prodKey desKey:(NSString *)desKey;

+(AhhhBuyChannelIPCheckSessionManager*)getIPCheckSessionManager;

-(void)ahhhstartAsyncRequestComplete:(void(^)(AhhhCSBuyChannelIPType type,NSError * _Nullable error))complete;

@end

NS_ASSUME_NONNULL_END
