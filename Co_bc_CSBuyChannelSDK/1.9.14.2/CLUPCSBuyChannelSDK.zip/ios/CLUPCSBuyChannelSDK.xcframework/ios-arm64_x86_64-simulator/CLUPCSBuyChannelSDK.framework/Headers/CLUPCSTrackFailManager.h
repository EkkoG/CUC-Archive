//
//  CLUPCSTrackFailManager.h
//  Pods
//
//  Created by qiaoming on 2020/3/23.
//

#import <Foundation/Foundation.h>
#import "CLUPCSTrackFailModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface CLUPCSTrackFailManager : NSObject

//上传失败  缓存到本地
+(void)cLUPsaveToCacheWithEvent:(NSString *)type uuid:(NSString *)uuid withValues:(NSDictionary *)values eventTime:(NSString *)eventTime;
//+(CLUPCSTrackFailModel*)cLUPunSerializedStatisticBeanFromFile:(NSString*)serializedBeanPath;
//+(void)cLUPdelSerializedBean:(CLUPCSTrackFailModel*)bean;
//+(NSArray <CLUPCSTrackFailModel *>*)cLUPgetSerializedStatisticBeanLst;
//再次上传失败的通知记录
+(void)cLUPretryUploadTrackEventRecordFormLocal;

@end

NS_ASSUME_NONNULL_END
